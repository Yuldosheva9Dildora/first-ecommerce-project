import Layout from "./components/layout/layout";

function App() {
  return <Layout />;
}

export default App;
